class Task {
    constructor(description, duedate, priority) {
        this.description = description;
        this.duedate = duedate;
        this.priority = priority;
        this.completed = false;
    }

    displayInfo() {
        console.log(`
            Assignee: ${this.assignee}
            Description: ${this.description}
            Due Date: ${this.duedate}
            Priority: ${this.priority}
            Project: ${this.project}
        `);
    }

    getRow() {
        const date = new Date(this.duedate).toLocaleString();
        return `
            <td>${this.description}</td>
            <td>${date.slice(0, date.lastIndexOf(':'))}</td>
            [ADD]
            <td>${this.priority}</td>
            <td>${this.completed ? "Yes" : "No"}</td>
        `;
    }
}

class WorkTask extends Task {
    constructor(params) {
        super(params.description, params.duedate, params.priority);
        this.assignee = params.assignee;
        this.project = params.project;
    }

    displayInfo() {
        super.displayInfo();
        console.log(`Department: ${this.department}`);
    }

    getRow() {
        return super.getRow().replace('[ADD]',
            `<td>${this.project}</td>
            <td>${this.assignee}</td>`
        );
    }
}

class PersonalTask extends Task {
    constructor(params) {
        super(params.description, params.duedate, params.priority);
        this.duration = params.duration;
        this.notes = params.notes;
    }

    displayInfo() {
        super.displayInfo();
        console.log(`Category: ${this.category}`);
    }

    getRow() {
        return super.getRow().replace('[ADD]',
            `<td>${this.duration} min</td>
            <td>${this.notes}</td>`
        );
    }
}
