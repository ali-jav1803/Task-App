function digitalClock() {
    const monthNames = [
        "January", "February", "March",
        "April", "May", "June", "July",
        "August", "September", "October",
        "November", "December"
    ];

    setInterval(updateClock, 1000);
    function updateClock() {
        const now = new Date();
        const date = String(now.getDate());
        const month = now.getMonth()
        const year = String(now.getFullYear());
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const timeString = `${date} ${monthNames[month]} ${year} ${hours}:${minutes}:${seconds}`;
        document.getElementById('clock').textContent = timeString;
    }

    updateClock();
}

async function fetchTasks(url) {
    return fetch(url)
    .then(response => {
        return response.json();
    })
    .then(data => {
        return data;
    })
}

function addEventListenerToRow(row) {
    row.addEventListener('click', () => {
        const rows = document.querySelectorAll('tr.selected');
        rows.forEach((curRow) => {
            if (row === curRow) return;
            curRow.classList.remove('selected');
        });
        row.classList.toggle('selected');
    })
}

async function populateDataInRows() {
    const tableBody = document.querySelectorAll('.dynamic-table tbody');
    const url = 'http://backend.restapi.co.za/items/'
    const personalTasks = await fetchTasks(url + 'ptasks');
    const workTasks = await fetchTasks(url + 'wtasks');

    personalTasks.data.forEach((item) => {
        const row = document.createElement('tr');
        addEventListenerToRow(row);
        const rowData = new PersonalTask(item);
        row.innerHTML = rowData.getRow();
        tableBody[0].appendChild(row);
    })

    workTasks.data.forEach(item => {
        const row = document.createElement('tr');
        addEventListenerToRow(row);
        const rowData = new WorkTask(item);
        row.innerHTML = rowData.getRow();
        tableBody[1].appendChild(row);
    })
}

digitalClock()
populateDataInRows()

function activateDeleteButtons() {
    const deleteButtons = document.querySelectorAll(`.delete-button`);
    deleteButtons.forEach((button) => button.addEventListener('click', () => {
        const row = document.querySelector('tr.selected');
        if (!row) {
            alert("Select a task first");
            return;
        }
        if (confirm("Do you really want to delete this task?"))
            row.remove();
        row.classList.toggle('selected');
    }))
}

function activateCompleteTaskButtons() {
    const completeTaskButtons = document.querySelectorAll(`.complete-task-button`);
    completeTaskButtons.forEach((button) => button.addEventListener('click', () => {
        const row = document.querySelector('tr.selected');
        if (!row) {
            alert("Select a task first");
            return;
        }
        if (row.innerHTML.includes("No")) {
            row.innerHTML = row.innerHTML.replace("No", "Yes")
        }
        row.classList.toggle('selected');
    }))
}

function activateChangePriorityButtons() {
    const changePriorityButtons = document.querySelectorAll(`.change-priority-button`);
    changePriorityButtons.forEach((button) => button.addEventListener('click', () => {
        const row = document.querySelector('tr.selected');
        if (!row) {
            alert("Select a task first");
            return;
        }
        option = prompt("Choose the new prioriy:\n1. low\n2. medium\n3. high\nEnter (1, 2 or 3)");
        options = ['1', '2', '3'];
        if (options.includes(option)) {
            priorities = ['low', 'medium', 'high'];
            replaced = false;
            options.forEach((opt) => {
                if (!replaced && row.innerHTML.includes(priorities[opt - 1])) {
                    row.innerHTML = row.innerHTML.replace(priorities[opt - 1], priorities[option - 1]);
                    replaced = true;
                }
            })
        }
        else {
            alert("Invalid option");
        }
        row.classList.toggle('selected');
    }))
}

function activateAddButton() {
    const addButtons = document.querySelectorAll(`.add-task-button`);
    addButtons.forEach((button) => button.addEventListener('click', () => {
        const isWork = button.classList.contains('work');
        const tables = document.querySelectorAll(`.dynamic-table tbody`);
        const table = tables[0].classList.contains('work') ? (isWork ? tables[0] : tables[1]) : (isWork ? tables[1] : tables[0]);
        const row = document.createElement('tr');
        let rowData = null;
        if (isWork) {
            const description = prompt("Enter description");
            let duedate = prompt("After how many hours is the task due?");
            duedate = new Date(Date.now() + duedate * 60 * 60 * 1000);
            const project = prompt("Enter project");
            const assignee = prompt("Enter assignee");
            const priority = prompt("Enter priority");

            rowData = new WorkTask({description, duedate, project, assignee, priority})
        }
        else {
            const description = prompt("Enter description");
            let duedate = prompt("After how many hours is the task due?");
            duedate = new Date(Date.now() + duedate * 60 * 60 * 1000);
            const duration = prompt("Enter duration");
            const notes = prompt("Enter notes");
            const priority = prompt("Enter priority");
            rowData = new PersonalTask({description, duedate, duration, notes, priority})
        }
        row.innerHTML = rowData.getRow();
        addEventListenerToRow(row);
        table.appendChild(row);
    }))
}

activateDeleteButtons()
activateCompleteTaskButtons()
activateChangePriorityButtons()
activateAddButton()

